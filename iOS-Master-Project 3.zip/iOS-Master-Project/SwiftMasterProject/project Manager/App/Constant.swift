//
//  Constant.swift
//  SwiftMasterProject
//
//  Created by Apple on 27/12/23.
//

import Foundation
import UIKit

//MARK: -  variable
typealias commonHandler = (() -> ())
