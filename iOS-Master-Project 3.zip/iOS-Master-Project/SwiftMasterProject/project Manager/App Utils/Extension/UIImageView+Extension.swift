////
////  UIImageView+Extension.swift
////
////  Created by Apple on 14/03/23.
////
//
//
//import SDWebImage
//extension UIImageView{
//    func setImageFromUrl(url : String){
//
//        self.sd_setImage(with: URL(string: url), placeholderImage: UIImage(named: "imagePlaceholder"))
//    }
//    func makeroundimage(){
//    
//        self.layer.cornerRadius = self.frame.size.height / 2
//        self.layer.masksToBounds = true
//    }
//    
//}
//
